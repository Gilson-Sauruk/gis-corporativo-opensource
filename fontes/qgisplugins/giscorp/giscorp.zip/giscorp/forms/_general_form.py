# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
import webbrowser, tempfile, os, math
from qgis.PyQt.QtCore import QTimer, QVariant, QByteArray, QBuffer, QFile, QObject
from qgis.PyQt.QtWidgets import QWidget, QTableWidgetItem, QPushButton, QDialogButtonBox, QAbstractItemView, QMessageBox, QLineEdit, QPlainTextEdit, QDockWidget, QSpinBox, QDoubleSpinBox, QDialog, QToolButton
from qgis.utils import iface
from qgis.core import QgsFeatureRequest, QgsVectorLayer, QgsFeature, QgsRelationManager, QgsProject, QgsVectorLayerUtils, QgsFields, QgsField, QgsGeometry, NULL
from qgis.gui import QgsMessageBar, QgsFileWidget, QgsAttributeForm

# --------------------------------------------------------------------------
# SERVICE FUNCTIONS
# --------------------------------------------------------------------------
def addAttachments(fid: int, filePaths: list):
    try:
        attachTable = QgsProject().instance().mapLayersByName(str('%s_anexos' % getTableDataSource()).lower())[0]
        for filePath in filePaths:
            attachTable.startEditing()
            fileName = os.path.basename(filePath)
            file = open(filePath, 'rb')
            raw = file.read()
            qba = QByteArray()
            blob = qba.fromRawData(raw)
            file.close()
            del file
            feature = QgsVectorLayerUtils.createFeature(attachTable, attributes={1: fid, 2: fileName, 3: blob})
            attachTable.addFeature(feature)
            attachTable.commitChanges(True)
    except Exception as e:
        iface.messageBar().pushMessage('Erro: %s' % str(e))

def delAttachments(ids: list):
    try:
        attachTable = QgsProject().instance().mapLayersByName(str('%s_anexos' % getTableDataSource()).lower())[0]
        attachTable.startEditing()
        attachTable.deleteFeatures(ids)
        attachTable.commitChanges(True)
    except Exception as e:
        iface.messageBar().pushMessage('Erro: %s' % str(e))

def getAttachments():
    relationsManager = QgsProject.instance().relationManager()
    relationTable = str('%s_anexos' % getTableDataSource()).lower()
    relationName = 'rel_%s' % relationTable
    relations = relationsManager.relationsByName(relationName)
    for relation in relations:
        request = relation.getRelatedFeaturesRequest(feature=feat)
        clause = QgsFeatureRequest.OrderByClause('anexo_nome', ascending=True)
        orderby = QgsFeatureRequest.OrderBy([clause])
        request.setOrderBy(orderby)
        attachTable = QgsProject().instance().mapLayersByName(relationTable)[0]
        attachList = [row for row in attachTable.getFeatures(request)]
        return attachList
    return []

def addTableRow(table, row_data):
    row = table.rowCount()
    table.setRowCount(row + 1)
    col = 0
    for item in row_data:
        cell = QTableWidgetItem(str(item))
        table.setItem(row, col, cell)
        col += 1

def delTableAllRows(table):
    table.clearSelection()
    for i in reversed(range(table.rowCount())):
        table.removeRow(i)

def getTableDataSource():
    try:
        return [str(prop.split('.')[1]).strip('"') for prop in lyr.source().replace('(geom)', '').split(' ') if str(prop).startswith('table')][0]
    except:
        return None

# --------------------------------------------------------------------------
# UI FUNCTIONS
# --------------------------------------------------------------------------
def getShapeProperties():
    geom: QgsGeometry = feat.geometry()
    if geom.wkbType() in [1, 2, 3, 4, 5, 6]:
        txCentroidX.setText(str(round(geom.centroid().asPoint().x(), 5)))
        txCentroidY.setText(str(round(geom.centroid().asPoint().y(), 5)))
    if geom.wkbType() in [2, 3, 5, 6]:
        txAngle.setText(str(round(geom.interpolateAngle(15)*180/math.pi)))
    if geom.wkbType() in [2, 5]:
        txLength.setText(str(round(geom.length(), 2)))
    if geom.wkbType() in [3, 6]:
        txPerimeter.setText(str(round(geom.length(), 2)))
        txArea.setText(str(round(geom.area(), 2)))

def checkEditStatus():
    if dlg.editable():
        #
        if feat.id() > 0:
            #dlg.featureSaved.emit(feature=feat)
            #lyr.featureAdded.emit(feature=feat['id'])
            #lyr.geometryChanged(fid=feat['id'], geometry=feat.geometry())
            #lyr.changeGeometry(fid=feat['id'], geometry=feat.geometry())
            if not btAttachAdd.isEnabled():
                btAttachAdd.setEnabled(True)
            if tbAttachments.rowCount() > 0:
                btAttachDel.setEnabled(True)
        else:
            btAttachAdd.setEnabled(False)
            btAttachDel.setEnabled(False)
            tbAttachments.setEnabled(True)
    else:
        btAttachAdd.setEnabled(False)
        btAttachDel.setEnabled(False)
        tbAttachments.setEnabled(True)

def refreshAttachmentsTable():
    delTableAllRows(table=tbAttachments)
    for attachment in getAttachments():
        addTableRow(table=tbAttachments, row_data=[attachment["id"], attachment['anexo_nome']])

def initUI():
    #
    tbAttachments.setColumnHidden(0, True)
    #
    btAttachOpen.setVisible(False)
    #
    if feat.id() > 0:
        #
        checkEditStatus()
        #
        getShapeProperties()
        #
        refreshAttachmentsTable()
        #
        # lyr.select([feat.id()])

def finishUI():
    timer.stop()

# --------------------------------------------------------------------------
# EVENT ACTIONS
# --------------------------------------------------------------------------
def btAttachOpen_fileChanged(path: str):
    filePaths = btAttachOpen.splitFilePaths(path)
    addAttachments(fid=feat['id'], filePaths=filePaths)
    btAttachOpen.setFilePath('')
    refreshAttachmentsTable()

def btAttachAdd_clicked():
    btOpen: QToolButton = btAttachOpen.findChildren(QToolButton)[1]
    btOpen.clicked.emit()

def btAttachDel_clicked():
    indexes = []
    for selectionRange in tbAttachments.selectedRanges():
        indexes.extend(range(selectionRange.topRow(), selectionRange.bottomRow() + 1))
    ids = [int(tbAttachments.item(index, 0).text()) for index in indexes]
    names = [tbAttachments.item(index, 1).text() for index in indexes]
    if len(ids) > 0:
        reply = QMessageBox.question(iface.mainWindow(), 'ATENÇÃO!',
                                     'Você está prestes a REMOVER DEFINITIVAMENTE a seleção de anexos! Deseja continuar?', QMessageBox.Yes,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            delAttachments(ids)
            refreshAttachmentsTable()
            if tbAttachments.rowCount() == 0:
                btAttachDel.setEnabled(False)
    else:
        QMessageBox.information(iface.mainWindow(),'Mensagem','Selecione um ou mais anexos na lista para excluir!')

def tbAttachments_cellDoubleClicked(row: int, column: int):
    oRow = tbAttachments.item(row, 0)
    if oRow is not None:
        id = oRow.text()
        attachTable = QgsProject().instance().mapLayersByName(str('%s_anexos' % getTableDataSource()).lower())[0]
        records = [record for record in attachTable.getFeatures() if record['id'] == int(id)]
        for record in records:
            tempFolder = tempfile.TemporaryDirectory().name
            os.mkdir(tempFolder)
            tempAttachmentFile = os.path.join(tempFolder, record['anexo_nome'])
            file = open(tempAttachmentFile, 'wb')
            file.write(record['anexo_dados'])
            file.close()
            webbrowser.open_new(tempAttachmentFile)

def btBox_accepted():
    #iface.messageBar().pushMessage('commitChanges')
    #lyr.changeGeometry(fid=feat['id'], geometry=feat.geometry())
    #lyr.commitChanges(False)
    #lyr.geometryChanged.emit(feat['id'], feat.geometry())
    #dlg.featureSaved.emit(feat)
    #iuri
    pass


def btBox_rejected():
    try:
        giscorp: QDockWidget = iface.mainWindow().findChild(QDockWidget, 'GiscorpEditDockWidgetBase')
        giscorp_btCancelar: QPushButton = giscorp.findChild(QPushButton, 'btCancelar')
        giscorp_btCancelar.clicked.emit()
    except Exception as e:
        iface.messageBar().pushMessage('Erro: %s' % str(e))

def dialog_widgetValueChanged(attribute, value, attributeChanged):
    #iface.messageBar().pushMessage('attributeChanged: %s, %s, %s' % (str(attribute), str(value), str(attributeChanged)))
    pass

def dialog_destroyed():
    finishUI()

def init(dialog, layer, feature):
    # set global variables
    global debug
    global dlg
    global lyr
    global feat
    global btAttachAdd
    global btAttachOpen
    global btAttachDel
    global tbAttachments
    global timer
    global txCentroidX
    global txCentroidY
    global txAngle
    global txLength
    global txPerimeter
    global txArea

    debug = False
    lyr = layer
    feat = feature
    dlg = dialog
    timer = QTimer()

    # assign UI controls
    btBox = dlg.findChild(QWidget, "btBox")
    btAttachAdd = dlg.findChild(QWidget, "btAttachAdd")
    btAttachOpen = QgsFileWidget(dlg)
    btAttachDel = dlg.findChild(QWidget, "btAttachDel")
    tbAttachments = dlg.findChild(QWidget, "tbAttachments")
    txCentroidX = dlg.findChild(QWidget, "txCentroidX")
    txCentroidY = dlg.findChild(QWidget, "txCentroidY")
    txAngle = dlg.findChild(QWidget, "txAngle")
    txLength = dlg.findChild(QWidget, "txLength")
    txPerimeter = dlg.findChild(QWidget, "txPerimeter")
    txArea = dlg.findChild(QWidget, "txArea")

    # connect events
    dlg.destroyed.connect(dialog_destroyed)
    dlg.widgetValueChanged.connect(dialog_widgetValueChanged)
    #btBox.accepted.connect(btBox_accepted)
    btBox.rejected.connect(btBox_rejected)
    btAttachAdd.clicked.connect(btAttachAdd_clicked)
    btAttachOpen.fileChanged.connect(btAttachOpen_fileChanged)
    btAttachDel.clicked.connect(btAttachDel_clicked)
    tbAttachments.cellDoubleClicked.connect(tbAttachments_cellDoubleClicked)
    timer.timeout.connect(checkEditStatus)
    timer.start(200)

    # initialize ui
    initUI()


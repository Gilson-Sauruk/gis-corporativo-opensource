import webbrowser, tempfile, os, math
from qgis.PyQt.QtCore import QTimer, QByteArray
from qgis.PyQt.QtWidgets import QTableWidgetItem, QTableWidget
from qgis.core import QgsFeatureRequest, QgsVectorLayer, QgsProject, QgsVectorLayerUtils, QgsGeometry, QgsMapLayerType
from qgis.utils import iface

class Util:

    def addTableRow(self, table: QTableWidget, row_data: list):
        row = table.rowCount()
        table.setRowCount(row + 1)
        col = 0
        for item in row_data:
            cell = QTableWidgetItem(str(item))
            table.setItem(row, col, cell)
            col += 1

    def delTableAllRows(self, table: QTableWidget):
        table.clearSelection()
        for i in reversed(range(table.rowCount())):
            table.removeRow(i)

    def isNotNone(self, val, default=''):
        return val if val is not None else default

    def getTableDataSource(self, vlayer: QgsVectorLayer):
        try:
            return [str(prop.split('.')[1]).strip('"') for prop in vlayer.source().replace('(geom)', '').split(' ') if
                    str(prop).startswith('table')][0]
        except Exception as e:
            raise Exception("Table datasource not found for layer. %s" % str(e))

    def getLayerByName(self, name: str):
        try:
            layers = QgsProject().instance().mapLayersByName(name)
            if len(layers) == 0:
                raise Exception('Layer does not exist on the map')
            else:
                return layers[0]
        except Exception as e:
            raise Exception(e)

    def getVectorLayerByTablename(self, name: str):
        for vlayer in [layer for layer in iface.mapCanvas().layers() if
                       layer.type() is QgsMapLayerType.VectorLayer and layer.wkbType() != 100]:
            table = self.getTableDataSource(vlayer=vlayer)
            if table.lower() == name.lower():
                return vlayer

    def getFeaturesByLocation(self, pointXY: QgsGeometry, searchedLayer: QgsVectorLayer, tolerance: float = 0.50):
        # primary filter (bounding box test)
        candidates = []
        for feature in searchedLayer.getFeatures():
            if pointXY.boundingBoxIntersects(rectangle=feature.geometry().boundingBox()):
                candidates.append(feature)
        # refinement (distance heuristic)
        finals = []
        for feature in candidates:
            if pointXY.distance(geom=feature.geometry()) <= tolerance:
                finals.append(feature)
        return finals

    def getGeometryProperties(self, geom: QgsGeometry):
        gType = geom.wkbType()
        centroidX, centroidY, angle, length, perimeter, area = None, None, None, None, None, None
        if gType in [1, 2, 3, 4, 5, 6]:
            centroidX = round(geom.centroid().asPoint().x(), 5)
            centroidY = round(geom.centroid().asPoint().y(), 5)
        if gType in [2, 3, 5, 6]:
            angle = round(geom.interpolateAngle(15) * 180 / math.pi)
        if gType in [2, 5]:
            length = round(geom.length(), 2)
        if gType in [3, 6]:
            perimeter = round(geom.length(), 2)
            area = round(geom.area(), 2)
        return centroidX, centroidY, angle, length, perimeter, area
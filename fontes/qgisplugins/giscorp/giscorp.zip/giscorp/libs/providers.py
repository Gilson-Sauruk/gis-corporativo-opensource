import os, tempfile, webbrowser
from qgis.PyQt.QtCore import QByteArray
from qgis.core import QgsFeatureRequest, QgsProject, QgsVectorLayerUtils, QgsVectorLayer, QgsFeature
from giscorp.libs.utils import Util

class AttachmentProvider:
    __attachmentRelationshipPrefix = 'rel'
    __attachmentRelationshipSuffix = '_anexos'
    __attachmentFieldDescription = 'anexo_nome'
    __attachmentFieldData = 'anexo_dados'
    __relationName = None
    __attachTable = None
    __vlayer: QgsVectorLayer = None

    def __init__(self, vlayer: QgsVectorLayer = None):
        if vlayer is not None:
            self.vlayer = vlayer

    @property
    def vlayer(self):
        return self.__vlayer

    @vlayer.setter
    def vlayer(self, val):
        self.__vlayer = val
        util = Util()
        primaryTableName = util.getTableDataSource(vlayer=self.__vlayer)
        attachmentRelationTableName = str('%s%s' % (primaryTableName, self.__attachmentRelationshipSuffix)).lower()
        self.__attachTable = QgsProject().instance().mapLayersByName(attachmentRelationTableName)[0]
        self.__relationName = '%s_%s' % (self.__attachmentRelationshipPrefix, attachmentRelationTableName)
        del util

    def addAttachments(self, fid: int, filePaths: list):
        try:
            if self.__vlayer is None:
                raise Exception("Invalid vector layer entity. you must set 'vlayer' property")
            for filePath in filePaths:
                self.__attachTable.startEditing()
                fileName = os.path.basename(filePath)
                file = open(filePath, 'rb')
                raw = file.read()
                qba = QByteArray()
                blob = qba.fromRawData(raw)
                file.close()
                del file
                feature = QgsVectorLayerUtils.createFeature(self.__attachTable, attributes={1: fid, 2: fileName, 3: blob})
                self.__attachTable.addFeature(feature)
                self.__attachTable.commitChanges(True)
        except Exception as e:
            raise Exception(e)

    def delAttachments(self, ids: list):
        try:
            if self.__vlayer is None:
                raise Exception("Invalid vector layer entity. you must set 'vlayer' property")
            self.__attachTable.startEditing()
            self.__attachTable.deleteFeatures(ids)
            self.__attachTable.commitChanges(True)
        except Exception as e:
            raise Exception(e)

    def getAttachments(self, selectedFeature: QgsFeature):
        try:
            if self.__vlayer is None:
                raise Exception("Invalid vector layer entity. you must set 'vlayer' property")
            relationsManager = QgsProject.instance().relationManager()
            relations = relationsManager.relationsByName(self.__relationName)
            #iface.messageBar().pushMessage('debug: %s' % str(self.__relationName))
            for relation in relations:
                request = relation.getRelatedFeaturesRequest(feature=selectedFeature)
                clause = QgsFeatureRequest.OrderByClause(self.__attachmentFieldDescription, ascending=True)
                orderby = QgsFeatureRequest.OrderBy([clause])
                request.setOrderBy(orderby)
                attachList = [row for row in self.__attachTable.getFeatures(request)]
                return attachList
            return []
        except Exception as e:
            raise Exception(e)

    def downloadAttachment(self, id: int):
        util = Util()
        attachTable = \
            QgsProject().instance().mapLayersByName(
                str('%s_anexos' % util.getTableDataSource(vlayer=self.__vlayer)).lower())[0]
        del util
        records = [record for record in attachTable.getFeatures() if record['id'] == int(id)]
        for record in records:
            tempFolder = tempfile.TemporaryDirectory().name
            os.mkdir(tempFolder)
            tempAttachmentFile = os.path.join(tempFolder, record[self.__attachmentFieldDescription])
            file = open(tempAttachmentFile, 'wb')
            file.write(record[self.__attachmentFieldData])
            file.close()
            webbrowser.open_new(tempAttachmentFile)
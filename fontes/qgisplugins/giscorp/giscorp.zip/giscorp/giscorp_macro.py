# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import QWidget, QMessageBox, QToolButton, QLineEdit, QPushButton, QTableWidget
from qgis.gui import QgsFileWidget
from qgis.utils import iface
from giscorp.libs.providers import AttachmentProvider
from giscorp.libs.utils import Util

def init(dialog, layer, feature):

    customizedForm = True if dialog.findChild(QWidget, "customDialogBase") is not None else False

    if customizedForm:

        # -----------------------------------------------------
        # Shape UI properties
        # -----------------------------------------------------

        def initShapeUI():
            util = Util()
            #
            centroidX, centroidY, angle, length, perimeter, area = util.getGeometryProperties(feature.geometry())
            #
            customFieldNames = {
                "txCentroidX": util.isNotNone(centroidX),
                "txCentroidY": util.isNotNone(centroidY),
                "txAngle": util.isNotNone(angle),
                "txLength": util.isNotNone(length),
                "txPerimeter": util.isNotNone(perimeter),
                "txArea": util.isNotNone(area)
            }
            # Set values in UI
            for key in customFieldNames.keys():
                control = dialog.findChild(QWidget, key)
                control.setText(str(customFieldNames[key]))

            # Disable 'id' field
            id: QLineEdit = dialog.findChild(QLineEdit, 'id')
            id.setEnabled(False)
            #
            del util

        initShapeUI()

        # -----------------------------------------------------
        # Attachments UI
        # -----------------------------------------------------

        btAttachAdd, btAttachOpen, btAttachDel, tbAttachments = QPushButton(), QPushButton(), QPushButton(), QTableWidget

        def btAttachAdd_clicked():
            btOpen: QToolButton = btAttachOpen.findChildren(QToolButton)[1]
            btOpen.clicked.emit()

        def btAttachDel_clicked():
            indexes = []
            for selectionRange in tbAttachments.selectedRanges():
                indexes.extend(range(selectionRange.topRow(), selectionRange.bottomRow() + 1))
            ids = [int(tbAttachments.item(index, 0).text()) for index in indexes]
            if len(ids) > 0:
                reply = QMessageBox.question(iface.mainWindow(), 'ATENÇÃO!',
                                             'Você está prestes a REMOVER DEFINITIVAMENTE a seleção de anexos! Deseja continuar?',
                                             QMessageBox.Yes,
                                             QMessageBox.No)
                if reply == QMessageBox.Yes:
                    attachProvider = AttachmentProvider(vlayer=layer)
                    attachProvider.delAttachments(ids)
                    del attachProvider
                    refreshAttachmentsTable()
                    if tbAttachments.rowCount() == 0:
                        btAttachDel.setEnabled(False)
            else:
                QMessageBox.information(iface.mainWindow(), 'Mensagem',
                                        'Selecione um ou mais anexos na lista para excluir!')

        def btAttachOpen_fileChanged(path: str):
            attachProvider = AttachmentProvider(vlayer=layer)
            filePaths = btAttachOpen.splitFilePaths(path)
            attachProvider.addAttachments(fid=feature.id(), filePaths=filePaths)
            btAttachOpen.setFilePath('')
            refreshAttachmentsTable()
            del attachProvider

        def tbAttachments_cellDoubleClicked(row: int, column: int):
            oRow = tbAttachments.item(row, 0)
            if oRow is not None:
                id = int(oRow.text())
                attachProvider = AttachmentProvider(vlayer=layer)
                attachProvider.downloadAttachment(id=id)
                del attachProvider

        def modifyInterface():
            if dialog.editable():
                #
                if feature.id() > 0:
                    if not btAttachAdd.isEnabled():
                        btAttachAdd.setEnabled(True)
                    if tbAttachments.rowCount() > 0:
                        btAttachDel.setEnabled(True)
                else:
                    btAttachAdd.setEnabled(False)
                    btAttachDel.setEnabled(False)
                    tbAttachments.setEnabled(True)
            else:
                btAttachAdd.setEnabled(False)
                btAttachDel.setEnabled(False)
                tbAttachments.setEnabled(True)

        def refreshAttachmentsTable():
            util = Util()
            attachProvider = AttachmentProvider(vlayer=layer)
            util.delTableAllRows(table=tbAttachments)
            for attachment in attachProvider.getAttachments(selectedFeature=feature):
                util.addTableRow(table=tbAttachments, row_data=[attachment["id"], attachment['anexo_nome']])
            del attachProvider
            del util

        def initAttachmentUI():
            tbAttachments.setColumnHidden(0, True)
            btAttachOpen.setVisible(False)
            if feature.id() > 0:
                modifyInterface()
                refreshAttachmentsTable()

        def dialog_destroyed():
            layer.editingStarted.disconnect(modifyInterface)
            layer.editingStopped.disconnect(modifyInterface)

        btAttachAdd: QPushButton = dialog.findChild(QPushButton, "btAttachAdd")
        btAttachOpen = QgsFileWidget(dialog)
        btAttachDel = dialog.findChild(QPushButton, "btAttachDel")
        tbAttachments = dialog.findChild(QTableWidget, "tbAttachments")
        btAttachAdd.clicked.connect(btAttachAdd_clicked)
        btAttachOpen.fileChanged.connect(btAttachOpen_fileChanged)
        btAttachDel.clicked.connect(btAttachDel_clicked)
        tbAttachments.cellDoubleClicked.connect(tbAttachments_cellDoubleClicked)
        layer.editingStarted.connect(modifyInterface)
        layer.editingStopped.connect(modifyInterface)
        dialog.destroyed.connect(dialog_destroyed)

        initAttachmentUI()

        # -----------------------------------------------------
        # Customized UI Actions
        # -----------------------------------------------------

        def setForeignKeyByLocation(foreignTables: list):
            def __function():
                if dialog.editable() and feature.id() < 0:
                    util = Util()
                    currentDataSourceTable = util.getTableDataSource(vlayer=layer).lower()
                    if currentDataSourceTable in foreignTables:
                        primaryTable = list(reversed(currentDataSourceTable.split('_')))[0]
                        for feat in util.getFeaturesByLocation(pointXY=feature.geometry(),searchedLayer=util.getVectorLayerByTablename(name=primaryTable)):
                            control = dialog.findChild(QWidget, "id_%s" % primaryTable)
                            index = control.findData(feat['id'])
                            control.setCurrentIndex(index)
                    del util
                oneTime.stop()
            oneTime = QTimer()
            oneTime.timeout.connect(__function)
            oneTime.start()

        setForeignKeyByLocation(foreignTables=['entrada_eta', 'saida_eta'])